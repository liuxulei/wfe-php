<?php
/**
 * @author liuxulei
 * 2015-2-13
 * adminController.php
 */

class adminController extends Controller_Action{
    
    public function channel(){
        
        echo 'channel';exit;
    }
    
    public function edit(){
        
    }
}